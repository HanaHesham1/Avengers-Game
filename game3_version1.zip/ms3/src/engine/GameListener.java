package engine;

import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.world.Champion;
import model.world.Direction;

public interface GameListener {
	public void onmove(Direction d) throws NotEnoughResourcesException, UnallowedMovementException;
	public void oncastAbillity(Ability a) throws NotEnoughResourcesException;
	public void oncastAbillity(Ability a,Direction d);
	public void oncastAbillity(Ability a,int x,int y);
	public Champion ongetCurrentChampion();
	public void onuseLeaderAbility();
	public void onplaceChampions();
	public void onplaceCover();
	public void onattack(Direction d);
	public void onendTurn();
	public boolean oncheckGameOver();
	public PriorityQueue ongetPriorityQueue();

}
