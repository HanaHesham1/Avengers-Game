package exceptions;

@SuppressWarnings("serial")
public class ChampionDisarmedException extends GameActionException {

	public ChampionDisarmedException() {
		super();
	}

	public ChampionDisarmedException(String s) {
		super(s);
	}

}
