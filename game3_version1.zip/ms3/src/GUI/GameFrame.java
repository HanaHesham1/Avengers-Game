package GUI;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;
import engine.Game;
import engine.GameListener;
import engine.Player;
import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;


public class GameFrame extends JFrame implements GameListener, ActionListener
{
	Player player1;
	Player player2;
	JLabel l1=new JLabel();
	JLabel l2=new JLabel();
	JTextArea p1;
	JTextArea p2;
	JPanel Grid=new JPanel();
	JButton leaderability1=new JButton();
	JButton leaderability2=new JButton();
	JLabel currentChampion;
	JLabel nextChampion;
	JTextArea remainingChampions1;
	JTextArea remainingChampions2;
	JPanel currentChampionDetails;
	JLabel currentDetails;
	JPanel end;
	JOptionPane championDetails,errorMessage,confirmCast;
	int counter;
	Game game;
	JLabel area1;
	JLabel area2;
	int i=0;
	public JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15;
	public buttonposition[][] gamegrid=new buttonposition[5][5];
	JButton move,up,down,right,left,castAbility,castDirectionalAbility, castSingleTargetAbility, attack,
			attackUp,attackDown,attackLeft,attackRight,abilityUp,abilityDown,abilityLeft,abilityRight,endTurn,ability1,ability2,ability3;

	public GameFrame(GameConfiguration g, Game newgame) throws IOException{
		String name1 =g.t1.getText();
		String name2 =g.t2.getText();
		l1.setText("Player 1: "+name1);
		l1.setBounds(100,30,200,50); 
	    l1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20)); add(l1);
	    leaderability1=new JButton("Leaderability1");
	    leaderability1.setBounds(100,80,400,50);
	    leaderability1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	    leaderability1.setText("Leaderability1");
	    leaderability1.addActionListener(this);
	    add(leaderability1);
	    p1 = new JTextArea("Player 1 champions: \n ");
	    p1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 12));
	    p1.setBounds(100,150,300,650); 
	    p1.setEditable(false);
	    add(p1);
	    remainingChampions1=new JTextArea(" Remaining Chamions: \n");
	    remainingChampions1.setBounds(100,300,300,300);
	    remainingChampions1.setEditable(false);
	    remainingChampions1.setVisible(false);
	    add(remainingChampions1);
		l2.setText("Player 2: "+name2);
		l2.setBounds(1500,30,200,50);
	    l2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20)); add(l2);
		leaderability2.setBounds(1500,80,400,50);
	    leaderability2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
		leaderability2.setText("LeaderAbility2");
		leaderability2.addActionListener(this);
		add(leaderability2);
		p2=new JTextArea("Player 2 champions: \n ");
		p2.setBounds(1500,150,300,650);
		p2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 12));
		p2.setEditable(false);
		add(p2);
		remainingChampions2=new JTextArea(" Remaining Chamions: \n");
		remainingChampions2.setBounds(1500,300,300,300);
		remainingChampions2.setEditable(false);
		remainingChampions2.setVisible(false);
		add(remainingChampions2);
		Grid.setLayout(new GridLayout(5,5));
		Grid.setBounds(550,150,800,500);
		add(Grid);
		endTurn=new JButton("End Turn");
		endTurn.setBounds(550,50,150,50);
		endTurn.addActionListener(this);
		endTurn.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
		add(endTurn);
		game=newgame;
		currentChampion=new JLabel();
		currentChampion.setBounds(0,300,200,80);
		nextChampion=new JLabel();
		nextChampion.setBounds(550,50,750,80);
		add(currentChampion);add(nextChampion);
		currentChampion.setVisible(true);
		nextChampion.setVisible(true);
		championDetails= new JOptionPane();
		for( int i=4;i>=0;i--){
			for( int j=0;j<gamegrid[i].length;j++){
				gamegrid[i][j]=new buttonposition();
				gamegrid[i][j].addActionListener(this);
				 Grid.add(gamegrid[i][j]);
			}
		}
		    b1=new JButton("Captain America");  
		    b1.setBounds(550,700,100,100);  
		    b1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b2=new JButton("Deadpool");  
		    b2.setBounds(650,700,100,100);
		    b2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b3=new JButton("Dr Strange");  
		    b3.setBounds(750,700,100,100); 
		    b3.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b4=new JButton("Electro");  
		    b4.setBounds(850,700,100,100);
		    b4.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b5=new JButton("Ghost Rider");  
		    b5.setBounds(950,700,100,100); 
		    b5.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b6=new JButton("Hela");  
		    b6.setBounds(550,800,100,100);  
		    b6.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b7=new JButton("Iceman");  
		    b7.setBounds(650,800,100,100);
		    b7.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b8=new JButton("Ironman");  
		    b8.setBounds(750,800,100,100);
		    b8.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b9=new JButton("Loki");  
		    b9.setBounds(850,800,100,100);  
		    b9.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b10=new JButton("Quicksilver");  
		    b10.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b10.setBounds(950,800,100,100);  
		    b11=new JButton("Spiderman");  
		    b11.setBounds(550,900,100,100);  
		    b11.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b12=new JButton("Thor");
		    b12.setBounds(650,900,100,100);
		    b12.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b13=new JButton("Venom");
		    b13.setBounds(750,900,100,100);
		    b13.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b14=new JButton("Yellow Jacket");
		    b14.setBounds(850,900,100,100);
		    b14.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b15=new JButton("Hulk");
		    b15.setBounds(950,900,100,100);
		    b15.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
		    b1.addActionListener(this);
		    b2.addActionListener(this);
		    b3.addActionListener(this);
		    b4.addActionListener(this);
		    b5.addActionListener(this);
		    b6.addActionListener(this);
		    b7.addActionListener(this);
		    b8.addActionListener(this);
		    b9.addActionListener(this);
		    b10.addActionListener(this);
		    b11.addActionListener(this);
		    b12.addActionListener(this);
		    b13.addActionListener(this);
		    b14.addActionListener(this);
		    b15.addActionListener(this);
		    
		    this.add(b1); this.add(b2); this.add(b3); this.add(b4); this.add(b5);
		    this.add(b6); this.add(b7); this.add(b8); this.add(b9); this.add(b10);
		    this.add(b11); this.add(b12); this.add(b13); this.add(b14); this.add(b15);
		    
		    
		    move=new JButton("Move");
		    move.setBounds(600,800,80,80);
		    add(move);
		    move.setVisible(false);
		    move.addActionListener(this);
		    up=new JButton("Up");
		    up.setBounds(600,720,80,80);
		    add(up);
		    up.setVisible(false);
		    up.addActionListener(this);
		    down=new JButton("Down");
		    down.setBounds(600,880,80,80);
		    add(down);
		    down.setVisible(false);
		    down.addActionListener(this);
		    left= new JButton("Left");
		    left.setBounds(520,800,80,80);
		    add(left);
		    left.setVisible(false);
		    left.addActionListener(this);
		    right=new JButton("Right");
		    right.setBounds(680,800,80,80);
		    add(right);
		    right.setVisible(false);
		    right.addActionListener(this);
		    attackLeft=new JButton("Left");
		    attackLeft.setBounds(780,800,80,80);
		    add(attackLeft);
		    attackLeft.setVisible(false);
		    attackLeft.addActionListener(this);
		    attack=new JButton("Attack");
		    attack.setBounds(860,800,80,80);
		    add(attack);
		    attack.setVisible(false);
		    attack.addActionListener(this);
		    attackRight= new JButton("Right");
		    attackRight.setBounds(940,800,80,80);
		    add(attackRight);
		    attackRight.setVisible(false);
		    attackRight.addActionListener(this);
		    attackUp=new JButton("Up");
		    attackUp.setBounds(860,720,80,80);
		    add(attackUp);
		    attackUp.setVisible(false);
		    attackUp.addActionListener(this);
		    attackDown=new JButton("Down");
		    attackDown.setBounds(860,880,80,80);
		    add(attackDown);
		    attackDown.setVisible(false);
		    attackDown.addActionListener(this);
		    castDirectionalAbility=new JButton("Cast Directional Ability");
		    castDirectionalAbility.setBounds(1120,800,80,80);
		    add(castDirectionalAbility);
		    castDirectionalAbility.setVisible(false);
		    castDirectionalAbility.addActionListener(this);
		    abilityLeft=new JButton("Left");
		    abilityLeft.setBounds(1040,800,80,80);
		    add(abilityLeft);
		    abilityLeft.setVisible(false);
		    abilityLeft.addActionListener(this);
		    abilityRight= new JButton("Right");
		    abilityRight.setBounds(1300,600,80,80);
		    add(abilityRight);
		    abilityRight.setVisible(false);
		    abilityRight.addActionListener(this);
		    abilityUp=new JButton("Up");
		    abilityUp.setBounds(1300, 700, 80, 80);
		    add(abilityUp);
		    abilityUp.setVisible(false);
		    abilityUp.addActionListener(this);
		    abilityDown= new  JButton("Down");
		    abilityDown.setBounds(1300,800,80,80);
		    add(abilityDown);
		    abilityDown.setVisible(false);
		    abilityDown.addActionListener(this);
		    castAbility=new JButton(" Cast Ability ");
		    castAbility.setBounds(1300,900,80,80);
		    add(castAbility);
		    castAbility.setVisible(false);
		    castAbility.addActionListener(this);
		    castSingleTargetAbility=new JButton(" cast Single target Ability");
		    castSingleTargetAbility.setBounds(1400,800,80,80);
		    add(castSingleTargetAbility);
		    castSingleTargetAbility.setVisible(false);
		    castSingleTargetAbility.addActionListener(this);
		    currentChampionDetails=new JPanel();
		    currentChampionDetails.setBounds(1050,550,300,500);
		    currentChampionDetails.setLayout(null);
		    currentChampionDetails.setVisible(false);
		    add(currentChampionDetails);
		    currentDetails=new JLabel();
		    currentDetails.setBounds(0,0,400,250);
		    currentChampionDetails.add(currentDetails);
		    ability1=new JButton();
		    ability1.setBounds(0,410,90,30);
		    ability1.addActionListener(this);
		    currentChampionDetails.add(ability1);
		    ability2=new JButton();
		    ability2.setBounds(110,410,90,30);
		    ability2.addActionListener(this);

		    currentChampionDetails.add(ability2);
		    ability3=new JButton();
		    ability3.setBounds(210,410,90,30);
		    ability3.addActionListener(this);

		    currentChampionDetails.add(ability3);
		    
		    
		    
		    
		    
		    
		  
		    
		    
		setSize(4000,4000);
		setLayout(null);  
	    setVisible(true); 
		
		
		String SPlayer1="";
		game.loadChampions("Champions.csv");
		game.loadAbilities("Abilities.csv");
	    
	    for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
			SPlayer1+=game.getFirstPlayer().getTeam().get(i).getName() +"\n"+
					"Maximum Health Points: "+game.getFirstPlayer().getTeam().get(i).getMaxHP()+
					" Mana: "+game.getFirstPlayer().getTeam().get(i).getMana()+" Maximum Action Points Per Turn: "+game.getFirstPlayer().getTeam().get(i).getMaxActionPointsPerTurn()+
					" Attack Range: "+game.getFirstPlayer().getTeam().get(i).getAttackRange()+" Attack Damage: "+game.getFirstPlayer().getTeam().get(i).getAttackDamage()+
					" Speed: "+game.getFirstPlayer().getTeam().get(i).getSpeed()+" Ability 1: "+game.getFirstPlayer().getTeam().get(i).getAbilities().get(0)+" Ability 2: "+game.getFirstPlayer().getTeam().get(i).getAbilities().get(1)+
					 " Ability 3: " +game.getFirstPlayer().getTeam().get(i).getAbilities().get(2)+"\n";
		}
		p1.setText(SPlayer1);
		String SPlayer2="";
		for(int i=0;i<g.player2.getTeam().size();i++){
			SPlayer2+=game.getSecondPlayer().getTeam().get(i).getName() +"\n"+
					"Maximum Health Points: "+g.player2.getTeam().get(i).getMaxHP()+
					" Mana: "+g.player2.getTeam().get(i).getMana()+" Maximum Action Points Per Turn: "+g.player1.getTeam().get(i).getMaxActionPointsPerTurn()+
					" Attack Range: "+g.player1.getTeam().get(i).getAttackRange()+" Attack Damage: "+g.player1.getTeam().get(i).getAttackDamage()+
					" Speed: "+g.player1.getTeam().get(i).getSpeed()+" Ability 1: "+g.player1.getTeam().get(i).getAbilities().get(0)+" Ability 2: "+g.player1.getTeam().get(i).getAbilities().get(1)+
					 " Ability 3: " +g.player1.getTeam().get(i).getAbilities().get(2)+"\n";
		}
		p2.setText(SPlayer2);
		add(p1);add(p2);
		onplaceCover();
	}
		
	public Champion pressedChampion(String name) {
		for(int i=0;i<game.getAvailableChampions().size();i++){
			if(name.equals(game.getAvailableChampions().get(i).getName())){
				return game.getAvailableChampions().get(i);
			}
			
		}
		return null;
	}
	public void onmove(Direction d){
		if(d==Direction.UP){
			try {
		Champion c=(Champion)game.getTurnOrder().peekMin();
		int x=c.getLocation().x;
		System.out.println("x"+x);
		int y=c.getLocation().y;
		System.out.println("y"+y);
		ImageIcon aa=(ImageIcon) gamegrid[x][y].getIcon();
			game.move(d);
			gamegrid[x+1][y].setIcon(aa);
			gamegrid[x][y].setIcon(null);
		} catch (NotEnoughResourcesException | UnallowedMovementException e) {
			errorMessage=new JOptionPane();
			errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
			errorMessage.showMessageDialog(this,e.getMessage());
			e.printStackTrace();
		}
		}	
		if(d==Direction.DOWN){
			try {
			Champion c=(Champion)game.getTurnOrder().peekMin();
			int x=c.getLocation().x;
			System.out.println("x"+x);
			int y=c.getLocation().y;
			System.out.println("y" +y);
			ImageIcon aa=(ImageIcon) gamegrid[x][y].getIcon();
			game.move(d);
			gamegrid[x-1][y].setIcon(aa);
			gamegrid[x][y].setIcon(null);
			} catch (NotEnoughResourcesException | UnallowedMovementException e) {
				errorMessage=new JOptionPane();
				errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
				errorMessage.showMessageDialog(this,e.getMessage());				e.printStackTrace();
			}
			}	
		if(d==Direction.RIGHT){
			try {
		Champion c=(Champion)game.getTurnOrder().peekMin();
		int x=c.getLocation().x;
		System.out.println(x);
		int y=c.getLocation().y;
		ImageIcon aa=(ImageIcon) gamegrid[x][y].getIcon();
			game.move(d);
			gamegrid[x][y+1].setIcon(aa);
			gamegrid[x][y].setIcon(null);
		} catch (NotEnoughResourcesException | UnallowedMovementException e) {
			errorMessage=new JOptionPane();
			errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
			errorMessage.showMessageDialog(this,e.getMessage());
			e.printStackTrace();
		}
		}

			if(d==Direction.LEFT){
				try {
			Champion c=(Champion)game.getTurnOrder().peekMin();
			int x=c.getLocation().x;
			System.out.println(x);
			int y=c.getLocation().y;
			ImageIcon aa=(ImageIcon) gamegrid[x][y].getIcon();
				game.move(d);
				gamegrid[x][y-1].setIcon(aa);
				gamegrid[x][y].setIcon(null);
			} catch (NotEnoughResourcesException | UnallowedMovementException e) {
				errorMessage=new JOptionPane();
				errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
				errorMessage.showMessageDialog(this,e.getMessage());
				e.printStackTrace();
			}
		}
		}	
        
		
	
	@Override
	public void oncastAbillity(Ability a) {
		try {
			game.castAbility(a);
		String data=" ";
		for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
			Champion c=game.getFirstPlayer().getTeam().get(i);
			
			 String d=("Name: "+c.getName()+"\n"+"Current Health Points: "+c.getCurrentHP()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					" Mana: "+c.getMana()+"\n"+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					" Attack Range: "+c.getAttackRange()+"\n"+" Attack Damage: "+c.getAttackDamage()+"\n"+
    					" Speed: "+c.getSpeed()+"\n"+ "Ability 1: "+c.getAbilities().get(0).getName()+"\n"+" Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
			
			data+=d+"\n";
			 //System.out.println(data);
		}
		p1.setText(data);
		data="";
		for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
			Champion c=game.getSecondPlayer().getTeam().get(i);
			String d=("Name: "+c.getName()+"\n"+"Current Health Points: "+c.getCurrentHP()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
					" Mana: "+c.getMana()+"\n"+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
					" Attack Range: "+c.getAttackRange()+"\n"+" Attack Damage: "+c.getAttackDamage()+"\n"+
					" Speed: "+c.getSpeed()+"\n"+ "Ability 1: "+c.getAbilities().get(0).getName()+"\n"+" Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
			data+=d+"\n";
		}
		p2.setText(data);
		for( int i=4;i>=0;i--){
			for( int j=0;j<gamegrid[i].length;j++){
				if(game.getBoard()[i][j] instanceof Cover){
					gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
					gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
					
				}
				if(game.getBoard()[i][j]==null){
					gamegrid[i][j].setIcon(null);
					gamegrid[i][j].setText(null);
					
				}
			}
	}
		oncheckGameOver();
		} catch (NotEnoughResourcesException | AbilityUseException
				| CloneNotSupportedException e) {
			errorMessage=new JOptionPane(e.getMessage());
			errorMessage.showMessageDialog(this,e.getMessage());
			e.printStackTrace();
		}
		
	}
	@Override
	public void oncastAbillity(Ability a, Direction d) {

		if(d==Direction.UP){
				try {
					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
				}
					catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					//errorMessage.showMessageDialog(this,"Can n);
					errorMessage.showMessageDialog(this,e.getMessage());	
					e.printStackTrace();
				}
			
		}
		else if(d==Direction.DOWN){
			
				try {

					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
				} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					errorMessage.showMessageDialog(this,e.getMessage());
					e.printStackTrace();
				} 
				
			
		}
		else if(d==Direction.LEFT){
				try {

					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
								} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					errorMessage.showMessageDialog(this,e.getMessage());
					e.printStackTrace();
				}
			
		}
		else if(d==Direction.RIGHT){
				try {

					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
								} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					errorMessage.showMessageDialog(this,e.getMessage());
					e.printStackTrace();
				}
				
			
		}
	
		abilityUp.setVisible(false);abilityDown.setVisible(false);abilityLeft.setVisible(false);abilityRight.setVisible(false);
		
	}
	@Override
	public void oncastAbillity(Ability a, int x, int y) {
		try {
			game.castAbility(a);
		String data=" ";
		for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
			Champion c=game.getFirstPlayer().getTeam().get(i);
			
			 String d=("Name: "+c.getName()+"\n"+"Current Health Points: "+c.getCurrentHP()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					" Mana: "+c.getMana()+"\n"+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					" Attack Range: "+c.getAttackRange()+"\n"+" Attack Damage: "+c.getAttackDamage()+"\n"+
    					" Speed: "+c.getSpeed()+"\n"+ "Ability 1: "+c.getAbilities().get(0).getName()+"\n"+" Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
			
			data+=d+"\n";
			 //System.out.println(data);
		}
		p1.setText(data);
		data="";
		for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
			Champion c=game.getSecondPlayer().getTeam().get(i);
			String d=("Name: "+c.getName()+"\n"+"Current Health Points: "+c.getCurrentHP()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
					" Mana: "+c.getMana()+"\n"+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
					" Attack Range: "+c.getAttackRange()+"\n"+" Attack Damage: "+c.getAttackDamage()+"\n"+
					" Speed: "+c.getSpeed()+"\n"+ "Ability 1: "+c.getAbilities().get(0).getName()+"\n"+" Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
			data+=d+"\n";
		}
		p2.setText(data);
		for( int i=4;i>=0;i--){
			for( int j=0;j<gamegrid[i].length;j++){
				if(game.getBoard()[i][j] instanceof Cover){
					gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
					gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
					
				}
				if(game.getBoard()[i][j]==null){
					gamegrid[i][j].setIcon(null);
					gamegrid[i][j].setText(null);
					
				}
			}
	}
		} catch (NotEnoughResourcesException | AbilityUseException
				| CloneNotSupportedException e) {
			errorMessage=new JOptionPane(e.getMessage());
			errorMessage.showMessageDialog(this,e.getMessage());
			e.printStackTrace();
		}

		}
	
	@Override
	public Champion ongetCurrentChampion() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void onuseLeaderAbility() {
		try {
			game.useLeaderAbility();
			for( int i=4;i>=0;i--){
				for( int j=0;j<gamegrid[i].length;j++){
					if(game.getBoard()[i][j] instanceof Cover){
						gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
						gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
						
					}
					if(game.getBoard()[i][j]==null){
						gamegrid[i][j].setIcon(null);
						gamegrid[i][j].setText(null);
						
					}
				}
		}
			oncheckGameOver();
		} catch (LeaderNotCurrentException e) {
			errorMessage=new JOptionPane(e.getMessage());
			errorMessage.showMessageDialog(this,e.getMessage());
			e.printStackTrace();
		} catch (LeaderAbilityAlreadyUsedException e) {
			errorMessage=new JOptionPane(e.getMessage());
			errorMessage.showMessageDialog(this,e.getMessage());
			e.printStackTrace();
			
		}
		
	}
	@Override
	public void onplaceChampions() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onplaceCover() {
		
	for(int i=0;i<=4;i++){
		for(int j=0;j<=4;j++){
			if(game.getBoard()[i][j] instanceof Cover){
				Icon icon=new ImageIcon("iceman.jpg");
				// gamegrid[i][j].setIcon(icon);
				 gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
			}
		}
	}
		
	}
	public void refreshBoard() {
		
	for(int i=0;i<=4;i++){
		for(int j=0;j<=4;j++){
			if(game.getBoard()[i][j] instanceof Cover){
				Icon icon=new ImageIcon("iceman.jpg");
				// gamegrid[i][j].setIcon(icon);
				 gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
			}
			if(game.getBoard()[i][j] instanceof Cover){
				Icon icon=new ImageIcon("iceman.jpg");
				// gamegrid[i][j].setIcon(icon);
				 gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
			}
		}
	}
		
	}
	
	@Override
	public void onattack(Direction d) {
		if(d==Direction.UP){
				try {
					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
				}
					catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					//errorMessage.showMessageDialog(this,"Can n);
					errorMessage.showMessageDialog(this,e.getMessage());	
					e.printStackTrace();
				}
			
		}
		else if(d==Direction.DOWN){
			
				try {

					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
				} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					errorMessage.showMessageDialog(this,e.getMessage());
					e.printStackTrace();
				} 
				
			
		}
		else if(d==Direction.LEFT){
				try {

					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
								} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					errorMessage.showMessageDialog(this,e.getMessage());
					e.printStackTrace();
				}
			
		}
		else if(d==Direction.RIGHT){
				try {

					game.attack(d);
					String data=" ";
//			    	  System.out.println("Adding to team 2" + game.getSecondPlayer().getTeam().size());

					for(int i=0;i<game.getFirstPlayer().getTeam().size();i++){
						Champion c=game.getFirstPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions1.append(data);
	
					}
					for(int i=0;i<game.getSecondPlayer().getTeam().size();i++){
						Champion c=game.getSecondPlayer().getTeam().get(i);
						 data=("Name: "+c.getName()+"Current Health Points: "+c.getCurrentHP()+"Maximum Health Points: "+c.getMaxHP()+
		        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
		        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
		        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
		        					 " Ability 3: " +c.getAbilities().get(2).getName() + "\n");
						remainingChampions2.append(data);
	
					}
					for( int i=4;i>=0;i--){
						for( int j=0;j<gamegrid[i].length;j++){
							if(game.getBoard()[i][j] instanceof Cover){
								gamegrid[i][j].setText(String.valueOf(((Cover) game.getBoard()[i][j]).getCurrentHP()));
								gamegrid[i][j].setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 15));
								
							}
							if(game.getBoard()[i][j]==null){
								gamegrid[i][j].setIcon(null);
								gamegrid[i][j].setText(null);
								
							}
						}
				}
					oncheckGameOver();
								} 
				catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e) {
					errorMessage=new JOptionPane();
					errorMessage.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
					errorMessage.showMessageDialog(this,e.getMessage());
					e.printStackTrace();
				}
				
			
		}
	}
	@Override
	public void onendTurn() {
		game.endTurn();
		Champion c=(Champion)game.getTurnOrder().peekMin();
		String details="Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
				"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
				"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
				"Speed: "+c.getSpeed()+"\n";
		currentDetails.setText(details);
		ability1.setText(c.getAbilities().get(0).getName()); 
		ability2.setText(c.getAbilities().get(1).getName());
		ability3.setText(c.getAbilities().get(2).getName());
		abilityUp.setVisible(false);abilityDown.setVisible(false);abilityLeft.setVisible(false);abilityRight.setVisible(false);
		
	
	}
	@Override
	public boolean oncheckGameOver() {
		if(game.getFirstPlayer().getTeam().size()==0){
			end=new JPanel();
			end.setLayout(null);
			end.setSize(4000,4000);
			add(end);
			JLabel winner=new JLabel("player 2 won");
			winner.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 40));
			end.add(winner);
			winner.setBounds(200,100,1000,1000);
			dispose();
			
		}
		
		else if (game.getSecondPlayer().getTeam().size()==0){
			end=new JPanel();
		end.setLayout(null);
		end.setSize(4000,4000);
		add(end);
		JLabel winner=new JLabel("player 1 won");
		winner.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 40));
		end.add(winner);
		winner.setBounds(200,100,1000,1000);
		dispose();
		}
		return false;
		
	}
	@Override
	public PriorityQueue ongetPriorityQueue() {
		// TODO Auto-generated method stub
		return null;
	}
//	public static void main(String[]args) throws IOException{
//	GameConfiguration g=new GameConfiguration();
//	new GameFrame(g,g.);
//	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==leaderability1){
			onuseLeaderAbility();
		}
		if(e.getSource()==leaderability2){
			onuseLeaderAbility();
		}
		
		Ability b=game.getAvailableAbilities().get(0);
		Boolean singleTargetAbility=false;
		if(e.getSource()==ability1){
			String details="";
			String type="";
			for(int i=0;i<game.getAvailableAbilities().size();i++){
				if(ability1.getText()==game.getAvailableAbilities().get(i).getName()){
				b=game.getAvailableAbilities().get(i);
				if( b instanceof HealingAbility)
					type="Healing Ability";
				else if( b instanceof DamagingAbility)
					type="Damaging Ability";
				else
					type="Crowd Control Ability";
				
				details="Name: "+b.getName()+" Type: " +type+ "Area of Effect"+b.getCastArea()+" Cast Range: "+b.getCastRange()+"Mana Cost: "+b.getManaCost()+" Required Action Points: "+b.getRequiredActionPoints()+
						" Current Cool Down: "+b.getCurrentCooldown()+" Base Cool Down: "+b.getBaseCooldown();
				
				}
			}
			int confirmCast=JOptionPane.showConfirmDialog(this,details);  
			if(confirmCast==JOptionPane.YES_OPTION){
				if(b.getCastArea()==AreaOfEffect.DIRECTIONAL){
					abilityUp.setVisible(true);abilityDown.setVisible(true);abilityLeft.setVisible(true);abilityRight.setVisible(true);
				}
				else if(b.getCastArea()==AreaOfEffect.SINGLETARGET){
				errorMessage= new JOptionPane("select your target");
				errorMessage.showMessageDialog(this,"select you target");
				singleTargetAbility=true;

				}
				else{
					oncastAbillity(b);
				}
			}
		}
		if(e.getSource()==ability2){
			String details="";
			String type="";
			for(int i=0;i<game.getAvailableAbilities().size();i++){
				if(ability2.getText()==game.getAvailableAbilities().get(i).getName()){
				b=game.getAvailableAbilities().get(i);
				if( b instanceof HealingAbility)
					type="Healing Ability";
				else if( b instanceof DamagingAbility)
					type="Damaging Ability";
				else
					type="Crowd Control Ability";
				
				details="Name: "+b.getName()+" Type: " +type+ "Area of Effect"+b.getCastArea()+" Cast Range: "+b.getCastRange()+"Mana Cost: "+b.getManaCost()+" Required Action Points: "+b.getRequiredActionPoints()+
						" Current Cool Down: "+b.getCurrentCooldown()+" Base Cool Down: "+b.getBaseCooldown();
				
				}
			}
			int confirmCast=JOptionPane.showConfirmDialog(this,details);  
			if(confirmCast==JOptionPane.YES_OPTION){
				if(b.getCastArea()==AreaOfEffect.DIRECTIONAL){
					abilityUp.setVisible(true);abilityDown.setVisible(true);abilityLeft.setVisible(true);abilityRight.setVisible(true);
				}
				else if(b.getCastArea()==AreaOfEffect.SINGLETARGET){
					errorMessage= new JOptionPane("select your target");
					errorMessage.showMessageDialog(this,"select you target");
					singleTargetAbility=true;
				}
				else{
					oncastAbillity(b);
				}
			}
		}
		if(e.getSource()==ability3){
			String details="";
			String type="";
			for(int i=0;i<game.getAvailableAbilities().size();i++){
				if(ability3.getText()==game.getAvailableAbilities().get(i).getName()){
				b=game.getAvailableAbilities().get(i);
				if( b instanceof HealingAbility)
					type="Healing Ability";
				else if( b instanceof DamagingAbility)
					type="Damaging Ability";
				else
					type="Crowd Control Ability";
				
				details="Name: "+b.getName()+" Type: " +type+ "Area of Effect"+b.getCastArea()+" Cast Range: "+b.getCastRange()+"Mana Cost: "+b.getManaCost()+" Required Action Points: "+b.getRequiredActionPoints()+
						" Current Cool Down: "+b.getCurrentCooldown()+" Base Cool Down: "+b.getBaseCooldown();
				
				}
			}
			int confirmCast=JOptionPane.showConfirmDialog(this,details);  
			if(confirmCast==JOptionPane.YES_OPTION){
				if(b.getCastArea()==AreaOfEffect.DIRECTIONAL){
					abilityUp.setVisible(true);abilityDown.setVisible(true);abilityLeft.setVisible(true);abilityRight.setVisible(true);
				}
				else if(b.getCastArea()==AreaOfEffect.SINGLETARGET){
					errorMessage= new JOptionPane("select your target");
					errorMessage.showMessageDialog(this,"select you target");
					singleTargetAbility=true;
				}
				else{
					oncastAbillity(b);
				}
			}
		}
		for( int i=4;i>=0;i--){
			for( int j=0;j<gamegrid[i].length;j++){
				if(e.getSource()==gamegrid[i][j]){
				
					oncastAbillity(b,i,j);
					System.out.println(i);
					System.out.println(j);
					//singleTargetAbility=false;
				}
			}}
		if(e.getSource()==abilityUp)
			oncastAbillity(b,Direction.UP);
		if(e.getSource()==abilityDown)
			oncastAbillity(b,Direction.DOWN);
		if(e.getSource()==abilityRight)
			oncastAbillity(b,Direction.RIGHT);
		if(e.getSource()==abilityLeft)
			oncastAbillity(b,Direction.LEFT);
		if(e.getSource()==endTurn){
		   onendTurn();
		}
		if(e.getSource()==move){
			up.setVisible(true);down.setVisible(true);left.setVisible(true);right.setVisible(true);
			Champion c=(Champion) game.getTurnOrder().peekMin();
		}
		if(e.getSource()==up){
        	onmove(Direction.UP); 	
        }
        else if(e.getSource()==down){
        	onmove(Direction.DOWN);
        }
        else if(e.getSource()==right)
        	onmove(Direction.RIGHT);
        else if(e.getSource()==left)
        	onmove(Direction.LEFT);

		if(e.getSource()==attack){
			attackUp.setVisible(true);attackDown.setVisible(true);attackLeft.setVisible(true);attackRight.setVisible(true);
			
		}
		if(e.getSource()==attackUp){
        	onattack(Direction.UP);
		}
		else if(e.getSource()==attackDown){
			onattack(Direction.DOWN);
		}
		else if(e.getSource()==attackLeft){
			onattack(Direction.LEFT);
		}
		else if (e.getSource()==attackRight){
			onattack(Direction.RIGHT);
		}
		if(e.getSource()==castDirectionalAbility){
			abilityUp.setVisible(true);abilityDown.setVisible(true);abilityLeft.setVisible(true);abilityRight.setVisible(true);	
		}
	if(i==6){
		game.placeChampions();
		System.out.println(game.getFirstPlayer().getTeam().size());
		System.out.println(game.getSecondPlayer().getTeam().size());
		System.out.println(game.getTurnOrder().size());
		for(int i=0;i<game.getTurnOrder().size();i++){
			System.out.println(game.getTurnOrder().peekMin());
			game.getTurnOrder().remove();
		}
		b1.setVisible(false);b2.setVisible(false);b3.setVisible(false);b4.setVisible(false);b4.setVisible(false);b5.setVisible(false);b6.setVisible(false);b7.setVisible(false);
		b8.setVisible(false);b9.setVisible(false);b10.setVisible(false);b11.setVisible(false);b12.setVisible(false);b13.setVisible(false);b14.setVisible(false);b15.setVisible(false);
		move.setVisible(true);
		attack.setVisible(true);
		castAbility.setVisible(false);
		castDirectionalAbility.setVisible(false);
		castSingleTargetAbility.setVisible(false);
		remainingChampions1.setVisible(false);
		remainingChampions2.setVisible(false);
		currentChampionDetails.setVisible(true);
		Champion c=(Champion)game.getTurnOrder().peekMin();
		String details="Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
				"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
				"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
				"Speed: "+c.getSpeed()+"\n";
		currentDetails.setText(details);
		ability1.setText(c.getAbilities().get(0).getName()); 
		ability2.setText(c.getAbilities().get(1).getName());
		ability3.setText(c.getAbilities().get(2).getName());
		
		
		
	}

	if(e.getSource()==b1){
		i++;		
			 String label=b1.getText();
		     String details="";
		     Champion a=game.getAvailableChampions().get(0);
		     for(int x=0;x<Game.getAvailableChampions().size();x++){
		        Champion c=Game.getAvailableChampions().get(x);
		            if(label.equals(c.getName())){ 
		            	a=c;
		            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
		        					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
		        					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
		        					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
		        					 "Ability 3: " +c.getAbilities().get(2).getName());
		            }
		     }
		      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
		      championDetails.showMessageDialog(this,details);
		      game.getTurnOrder().insert(a);
		      b1.setEnabled(false);
		  
		      if(i<=3){
			      game.getFirstPlayer().getTeam().add(pressedChampion(b1.getText()));
			      p1.append("\n"+details+"\n");
			      }
			      else if(i>3&&i<=6){
			    	  game.getSecondPlayer().getTeam().add(pressedChampion(b1.getText()));
			    	  p2.append("\n"+details+"\n");
			      }		
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("Captain America.png"));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("Captain America.png"));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("Captain America.png"));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("Captain America.png"));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("Captain America.png"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("Captain America.png"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b2){
		i++;
		 String label=b2.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				    a=c; 
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b2.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b2.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
	      b2.setEnabled(false);
	      if(i==1){
				gamegrid[0][1].setIcon(new ImageIcon("deadpool.png"));
				a.setLocation(new Point(0,1));
				game.getFirstPlayer().setLeader(a);
			}
			if(i==2){
				gamegrid[0][2].setIcon(new ImageIcon("deadpool.png"));
				a.setLocation(new Point(0,2));
			}
			if(i==3){
				gamegrid[0][3].setIcon(new ImageIcon("deadpool.png"));
				a.setLocation(new Point(0,3));
			}
			if(i==4){
				gamegrid[4][1].setIcon(new ImageIcon("deadpool.png"));
				a.setLocation(new Point(4,1));
				game.getSecondPlayer().setLeader(a);
			}
			if(i==5){
				gamegrid[4][2].setIcon(new ImageIcon("deadpool.png"));
				a.setLocation(new Point(4,2));
			}
			if(i==6){
				gamegrid[4][3].setIcon(new ImageIcon("deadpool.png"));
				a.setLocation(new Point(4,3));
			}
	}
	else if(e.getSource()==b3){
		i++;
		 String label=b3.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b3.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b3.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b3.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
	      if(i==1){
				gamegrid[0][1].setIcon(new ImageIcon("doctor strange.png"));
				a.setLocation(new Point(0,1));
				game.getFirstPlayer().setLeader(a);
			}
			if(i==2){
				gamegrid[0][2].setIcon(new ImageIcon("doctor strange.png"));
				a.setLocation(new Point(0,2));
			}
			if(i==3){
				gamegrid[0][3].setIcon(new ImageIcon("doctor strange.png"));
				a.setLocation(new Point(0,3));
			}
			if(i==4){
				gamegrid[4][1].setIcon(new ImageIcon("doctor strange.png"));
				a.setLocation(new Point(4,1));
				game.getSecondPlayer().setLeader(a);
			}
			if(i==5){
				gamegrid[4][2].setIcon(new ImageIcon("doctor strange.png"));
				a.setLocation(new Point(4,2));
				game.getBoard()[4][2]=a;
			}
			if(i==6){
				gamegrid[4][3].setIcon(new ImageIcon("doctor strange.png"));
				a.setLocation(new Point(4,3));
			}
	}
	else if(e.getSource()==b4){
		i++;
		 String label=b4.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b4.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b4.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b4.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b4.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("Electro.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("Electro.jpg"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("Electro.jpg"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("Electro.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("Electro.jpg"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("Electro.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	if(e.getSource()==b5){
		i++;
		 String label=b5.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b5.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b5.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b5.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b5.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("ghost rider.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("ghost rider.jpg"));
			a.setLocation(new Point(0,2));
			game.getBoard()[0][2]=a;
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("ghost rider.jpg"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("ghost rider.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("ghost rider.jpg"));
			a.setLocation(new Point(4,2));
			game.getBoard()[4][2]=a;
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("ghost rider.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b6){
		i++;
		 String label=b6.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b6.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b6.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b6.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b6.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("Hela.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("Hela.jpg"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("Hela.jpg"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("Hela.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("Hela.jpg"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("Hela.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b7){
		i++;
	
		 String label=b7.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b7.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	     }}
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b7.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b7.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b7.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("iceman.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("iceman.jpg"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("iceman.jpg"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("iceman.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("iceman.jpg"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("iceman.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b8){
		i++;
		 String label=b8.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	        	a=c;
	            if(label.equals(c.getName())){
				      b8.setEnabled(false);
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b8.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b8.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b8.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("ironman.png"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("ironman.png"));
			a.setLocation(new Point(0,2));
			game.getBoard()[0][2]=a;
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("ironman.png"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("ironman.png"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("ironman.png"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("ironman.png"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b9){
		i++;
		 String label=b9.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b9.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b9.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b9.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b9.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("loki.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("loki.jpg"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("loki.jpg"));
			a.setLocation(new Point(0,3));
			game.getBoard()[0][3]=a;
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("loki.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("loki.jpg"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("loki.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b10)  {
		i++;
		 String label=b10.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b10.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b10.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b10.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b10.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("Quicksilver.png"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("Quicksilver.png"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("Quicksilver.png"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("Quicksilver.png"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("Quicksilver.png"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("Quicksilver.png"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b11){
		i++;
		 String label=b11.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b11.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b11.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b11.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b11.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("spiderman.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("spiderman.jpg"));
			a.setLocation(new Point(0,2));
			game.getBoard()[0][2]=a;
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("spiderman.jpg"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("spiderman.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("spiderman.jpg"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("spiderman.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b12){
		i++;
		 String label=b12.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	        	a=c;
	            if(label.equals(c.getName())){
				      b12.setEnabled(false);
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b12.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b12.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b12.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("thor.png"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("thor.png"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("thor.png"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("thor.png"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("thor.png"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("thor.png"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b13){
		i++;
		 String label=b13.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	        	a=c;
	            if(label.equals(c.getName())){
				      b13.setEnabled(false);
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b13.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b13.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b13.setEnabled(false);
		
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("venom.png"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("venom.png"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("venom.png"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("venom.png"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("venom.png"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("venom.png"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b14){
		i++;
		 String label=b14.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<Game.getAvailableChampions().size();x++){
	        	Champion c=Game.getAvailableChampions().get(x);
	        	a=c;
	            if(label.equals(c.getName())){
				      b14.setEnabled(false);
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	            }
	     }
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b14.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b14.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b14.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("yellow jacket.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("yellow jacket.jpg"));
			a.setLocation(new Point(0,2));
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("yellow jacket.jpg"));
			a.setLocation(new Point(0,3));
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("yellow jacket.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("yellow jacket.jpg"));
			a.setLocation(new Point(4,2));
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("yellow jacket.jpg"));
			a.setLocation(new Point(4,3));
		}
	}
	else if(e.getSource()==b15){
		i++;
		 String label=b15.getText();
	     String details="";
	     Champion a=game.getAvailableChampions().get(0);
	     for(int x=0;x<game.getAvailableChampions().size();x++){
	        	Champion c=game.getAvailableChampions().get(x);
	            if(label.equals(c.getName())){
				      b15.setEnabled(false);
				      a=c;
	            details=("Name: "+c.getName()+"\n"+"Maximum Health Points: "+c.getMaxHP()+"\n"+
    					"Mana: "+c.getMana()+"\n"+"Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+"\n"+
    					"Attack Range: "+c.getAttackRange()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+
    					"Speed: "+c.getSpeed()+"\n"+"Ability 1: "+c.getAbilities().get(0).getName()+"\n"+"Ability 2: "+c.getAbilities().get(1).getName()+"\n"+
    					 "Ability 3: " +c.getAbilities().get(2).getName());
	     }}
	      championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
	      championDetails.showMessageDialog(this,details);
	      game.getTurnOrder().insert(a);
	      if(i<=3){
		      game.getFirstPlayer().getTeam().add(pressedChampion(b15.getText()));
		      p1.append("\n"+details+"\n");
		      }
		      else if(i>3&&i<=6){
		    	  game.getSecondPlayer().getTeam().add(pressedChampion(b15.getText()));
		    	  p2.append("\n"+details+"\n");
		      }			
		b15.setEnabled(false);
		if(i==1){
			gamegrid[0][1].setIcon(new ImageIcon("hulk.jpg"));
			a.setLocation(new Point(0,1));
			game.getFirstPlayer().setLeader(a);
		}
		if(i==2){
			gamegrid[0][2].setIcon(new ImageIcon("hulk.jpg"));
			a.setLocation(new Point(0,2));
			
		}
		if(i==3){
			gamegrid[0][3].setIcon(new ImageIcon("hulk.jpg"));
			a.setLocation(new Point(0,3));
			
		}
		if(i==4){
			gamegrid[4][1].setIcon(new ImageIcon("hulk.jpg"));
			a.setLocation(new Point(4,1));
			game.getSecondPlayer().setLeader(a);
		}
		if(i==5){
			gamegrid[4][2].setIcon(new ImageIcon("hulk.jpg"));
			a.setLocation(new Point(4,2));
			
		}
		if(i==6){
			gamegrid[4][3].setIcon(new ImageIcon("hulk.jpg"));
			a.setLocation(new Point(4,3));
			
		}
	}}
	public static void main(String []args) throws IOException{
		
		
	}

}