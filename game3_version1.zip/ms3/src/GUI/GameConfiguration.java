package GUI;
import java.awt.*;  
import java.awt.event.*;  
import java.io.IOException;

import javax.swing.*;  
import javax.swing.text.JTextComponent;

import model.abilities.Ability;
import model.world.Champion;
import model.world.Direction;
import engine.Game;
import engine.GameListener;
import engine.Player;
import engine.PriorityQueue;

public class GameConfiguration extends JFrame implements ActionListener,MouseListener, GameListener{  
//FirstApp first= new FirstApp(this);
private static Object add;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,bNext; 
JTextArea area1=new JTextArea("Player 1 champions, "+"\n"+" please notice that the first champion "+"\n"+"  you choose will be the leader\n"); 
JTextArea area2=new JTextArea("Player 2 champions, "+"\n"+" please notice that the first champion "+"\n"+"  you choose will be the leader\n"); 
JTextField t1=new JTextField();
JTextField t2=new JTextField();
JLabel l1=new JLabel("Enter player 1 name"); 
JLabel l2=new JLabel("Enter player 2 name"); 
JLabel l3=new JLabel("Please choose 3 champions only for each player");
JTextArea area3=new JTextArea(" Champion details\n");
int p1Count=0;
String label;
Player player1;
Player player2;
JOptionPane championDetails= new JOptionPane();
Game newGame;
public int i=0;

GameConfiguration() throws IOException {  
    //super("GameConfiguration - JavaTpoint");
	l1.setBounds(50,100,300,100);
    l1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20)); add(l1);
    t1.setBounds(50,200,300,100); 
    t1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));add(t1);
    player1= new Player(t1.getText());
    area1.setBounds(50,300, 295,500); add(area1);
    area1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 14)); add(area1);
    l2.setBounds(350,100,300,100);
    l2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20)); add(l2);
    t2.setBounds(350,200,300,100);
    t2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));add(t2);
    player2= new Player(t2.getText());
    newGame= new Game(player1,player2);
    b1=new JButton("Captain America");  
    b1.setBounds(700,200,200,100);  
    b1.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b2=new JButton("Deadpool");  
    b2.setBounds(900,200,200,100);
    b2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b3=new JButton("Dr Strange");  
    b3.setBounds(1100,200,200,100); 
    b3.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b4=new JButton("Electro");  
    b4.setBounds(1300,200,200,100);
    b4.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b5=new JButton("Ghost Rider");  
    b5.setBounds(1500,200,200,100); 
    b5.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b6=new JButton("Hela");  
    b6.setBounds(700,300,200,100);  
    b6.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b7=new JButton("Iceman");  
    b7.setBounds(900,300,200,100);
    b7.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b8=new JButton("Ironman");  
    b8.setBounds(1100,300,200,100);
    b8.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b9=new JButton("Loki");  
    b9.setBounds(1300,300,200,100);  
    b9.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b10=new JButton("Quicksilver");  
    b10.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b10.setBounds(1500,300,200,100);  
    b11=new JButton("Spiderman");  
    b11.setBounds(700,400,200,100);  
    b11.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b12=new JButton("Thor");
    b12.setBounds(900,400,200,100);
    b12.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b13=new JButton("Venom");
    b13.setBounds(1100,400,200,100);
    b13.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b14=new JButton("Yellow Jacket");
    b14.setBounds(1300,400,200,100);
    b14.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    b15=new JButton("Hulk");
    b15.setBounds(1500,400,200,100);
    b15.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
    
    area2.setBounds(350,300,295,500); 
    area2.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 14)); add(l2);add(area2);
    l3.setBounds(700,100,500,100);
    l3.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20)); add(l3);
    bNext=new JButton("Play");
    bNext.setBounds(800,700,300,100); 
    bNext.setBackground(Color.red);
    bNext.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 40)); add(bNext);
    
   
    b1.addActionListener(this);
    b2.addActionListener(this);  
    b3.addActionListener(this);  
    b4.addActionListener(this);  
    b5.addActionListener(this);  
    b6.addActionListener(this);  
    b7.addActionListener(this);  
    b8.addActionListener(this);  
    b9.addActionListener(this);
    b10.addActionListener(this);
    b11.addActionListener(this); 
    b12.addActionListener(this);
    b13.addActionListener(this);
    b14.addActionListener(this);
    b15.addActionListener(this);
    bNext.addActionListener(this);
    add(b1);add(b2);add(b3);add(b4);add(b5);add(b6);add(b7);add(b8);add(b9);add(b10);add(b11);add(b12);add(b13);add(b14);add(b15);
   Game.loadAbilities("Abilities.csv");
//    Game.loadChampions("Champions.csv");
    setLayout(null);  
    setSize(4000,4000);
    setVisible(true); 
}  

public Champion pressedChampion(String name) {
	
	for(int i=0;i<Game.getAvailableChampions().size();i++){
		if(name.equals(Game.getAvailableChampions().get(i))){
			return Game.getAvailableChampions().get(i);
		}
	}
	return null;
	
}
public void actionPerformed(ActionEvent e){ 
	if(e.getSource()==bNext){
				try {
					new GameFrame(this,newGame);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			// TODO Auto-generated catch block
		}
}
//	else if(e.getSource() instanceof JButton && !((JButton) e.getSource()).getLabel().equals("Play")){  
//        String label=((JButton)e.getSource()).getLabel();
//        if(p1Count<3){
//        	String details="";
//        	for(int i=0;i<Game.getAvailableChampions().size();i++){
//            	Champion c=Game.getAvailableChampions().get(i);
//            	if(label.equals(c.getName())){
//        		details=("Name: "+c.getName()+"Maximum Health Points: "+c.getMaxHP()+
//        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
//        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
//        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0).getName()+" Ability 2: "+c.getAbilities().get(1).getName()+
//        					 " Ability 3: " +c.getAbilities().get(2).getName());
//        	
//        	}
//            	
//            	}
//            championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
//      championDetails.showMessageDialog(this,details);
//      
//        area1.append("\n"+label+"\n");
//        ((JButton)e.getSource()).setEnabled(false);
//        p1Count++;
//        newGame.getFirstPlayer().getTeam().add(pressedChampion(((JButton) e.getSource()).getLabel()));
//        }
//        else if(p1Count<6 &&!((JButton) e.getSource()).getLabel().equals("Play")){
//        	String details="";
//        	for(int i=0;i<Game.getAvailableChampions().size();i++){{
//            	Champion c=Game.getAvailableChampions().get(i);
//        		details=("Name: "+c.getName()+"Maximum Health Points: "+c.getMaxHP()+
//        					" Mana: "+c.getMana()+" Maximum Action Points Per Turn: "+c.getMaxActionPointsPerTurn()+
//        					" Attack Range: "+c.getAttackRange()+" Attack Damage: "+c.getAttackDamage()+
//        					" Speed: "+c.getSpeed()+" Ability 1: "+c.getAbilities().get(0)+" Ability 2: "+c.getAbilities().get(1)+
//        					 " Ability 3: " +c.getAbilities().get(2));
//        	
//        	}}
//       championDetails.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
//
//      championDetails.showMessageDialog(this,details);
//      
//       	 area2.append("\n"+label+"\n");
//       	 ((JButton)e.getSource()).setEnabled(false);
//          p1Count++;	
//          newGame.getSecondPlayer().getTeam().add(pressedChampion(((JButton) e.getSource()).getLabel()));
//       }
//        else{
//        	//code moving to the next panel
//        }
//        
//    }  
//      
    //congrats code  
//    if(b1.getLabel().equals("1")&&b2.getLabel().equals("2")&&b3.getLabel()    
//            .equals("3")&&b4.getLabel().equals("4")&&b5.getLabel().equals("5")    
//            &&b6.getLabel().equals("6")&&b7.getLabel().equals("7")&&b8.getLabel()    
//            .equals("8")&&b9.getLabel().equals("")){     
//            JOptionPane.showMessageDialog(this,"Congratulations! You won.");    
//    } 
//    if(e.getSource()==b1){
//    	i++;
//    	if(i==1){
//    		grid
//    	}
//    		
//    }




@Override
public void mouseExited(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}
@Override
public void mousePressed(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}
@Override
public void mouseReleased(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}
@Override
public void onmove(Direction d) {
	// TODO Auto-generated method stub
	
}
@Override
public void oncastAbillity(Ability a) {
	// TODO Auto-generated method stub
	
}
@Override
public void oncastAbillity(Ability a, Direction d) {
	// TODO Auto-generated method stub
	
}
@Override
public void oncastAbillity(Ability a, int x, int y) {
	// TODO Auto-generated method stub
	
}
@Override
public Champion ongetCurrentChampion() {
	// TODO Auto-generated method stub
	return null;
}
@Override
public void onuseLeaderAbility() {
	// TODO Auto-generated method stub
	
}
@Override
public void onplaceChampions() {
	// TODO Auto-generated method stub
	
}
@Override
public void onplaceCover() {
	// TODO Auto-generated method stub
	
}
@Override
public void onattack(Direction d) {
	// TODO Auto-generated method stub
	
}
@Override
public void onendTurn() {
	// TODO Auto-generated method stub
	
}
@Override
public boolean oncheckGameOver() {
	// TODO Auto-generated method stub
	return false;
}
@Override
public PriorityQueue ongetPriorityQueue() {
	// TODO Auto-generated method stub
	return null;
}
public static void main(String []args) throws IOException{
	new GameConfiguration();
}

@Override
public void mouseClicked(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseEntered(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

}