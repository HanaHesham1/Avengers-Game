package GUI;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

public class Gameover {
    JLabel end;
	public Gameover(String name) {
		end.setBounds(500, 500, 200, 200);
		end.setText(name +  " is the WINNER ");
		end.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 12));
		end.setVisible(true);
	}

}
